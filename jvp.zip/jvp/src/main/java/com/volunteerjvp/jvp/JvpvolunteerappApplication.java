package com.volunteerjvp.jvp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JvpvolunteerappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JvpvolunteerappApplication.class, args);
	}

}
